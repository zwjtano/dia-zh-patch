#import <AppKit/AppKit.h>
#import <objc/runtime.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Exact UI translations; read-only labels are scoped to settings and skill views.
// Editable/selectable fields, web content, network and authentication are not translated.
static NSDictionary<NSString *, NSString *> *translations;
static NSString *appRoot;
static FILE *translationAudit;
static FILE *missingAudit;
static NSSet<NSString *> *knownUI;
static NSMutableSet<NSString *> *reportedMissing;
static void recordMissing(NSString *text) {
    if (!missingAudit || !text || ![knownUI containsObject:text]) return;
    @synchronized (reportedMissing) {
        if ([reportedMissing containsObject:text]) return;
        [reportedMissing addObject:text];
        fprintf(missingAudit, "%s\n", text.UTF8String);
        fflush(missingAudit);
    }
}
static NSDictionary<NSString *, NSString *> *skillDisplayTranslations;
static BOOL isScopedLabel(NSTextField *field) {
    if (field.isEditable || field.isSelectable) return NO;
    for (NSResponder *view = field; view; view = view.nextResponder) {
        NSString *name = NSStringFromClass(view.class);
        if ([name hasPrefix:@"Preferences."] || [name hasPrefix:@"SkillsSharedUI."] || [name hasPrefix:@"Spaces."] || [name hasPrefix:@"Dialogs."])
            return YES;
    }
    return NO;
}
static NSString *labelTranslation(NSString *text) {
    if (!skillDisplayTranslations[text] && !translations[text]) recordMissing(text);
    return skillDisplayTranslations[text] ?: translations[text] ?: text;
}
static void (*originalFieldString)(NSTextField *, SEL, NSString *);
static void (*originalPlaceholder)(NSTextField *, SEL, NSString *);
static void placeholder(NSTextField *self, SEL cmd, NSString *value) {
    // Placeholder is UI metadata. Never replace stringValue or a text binding.
    NSString *result = value ? translations[value] : nil;
    originalPlaceholder(self, cmd, result ?: value);
}
static void (*originalAttributedPlaceholder)(NSTextField *, SEL, NSAttributedString *);
static void attributedPlaceholder(NSTextField *self, SEL cmd, NSAttributedString *value) {
    NSString *result = value.string ? translations[value.string] : nil;
    if (result) {
        NSMutableAttributedString *copy = [value mutableCopy];
        [copy replaceCharactersInRange:NSMakeRange(0, copy.length) withString:result];
        originalAttributedPlaceholder(self, cmd, copy);
    } else originalAttributedPlaceholder(self, cmd, value);
}
static void fieldString(NSTextField *self, SEL cmd, NSString *value) {
    if (!self.isEditable && !self.isSelectable && !translations[value] && !skillDisplayTranslations[value]) recordMissing(value);
    originalFieldString(self, cmd, isScopedLabel(self) ? labelTranslation(value) : value);
}
static void (*originalFieldAttributed)(NSTextField *, SEL, NSAttributedString *);
static void fieldAttributed(NSTextField *self, SEL cmd, NSAttributedString *value) {
    NSString *source = value.string;
    NSString *result = isScopedLabel(self) ? labelTranslation(source) : source;
    if (![source isEqualToString:result]) {
        NSMutableAttributedString *copy = [value mutableCopy];
        [copy replaceCharactersInRange:NSMakeRange(0, copy.length) withString:result];
        originalFieldAttributed(self, cmd, copy);
    } else if (isScopedLabel(self)) {
        // A help link may be one attributed run after an already translated sentence.
        NSMutableAttributedString *copy = [value mutableCopy];
        [value enumerateAttribute:NSLinkAttributeName inRange:NSMakeRange(0,value.length) options:NSAttributedStringEnumerationReverse usingBlock:^(id link, NSRange range, BOOL *stop) {
            (void)stop;
            if (!link) return;
            NSString *part = [value.string substringWithRange:range];
            NSString *replacement = translations[part];
            if (!replacement) return;
            NSDictionary *attributes = [value attributesAtIndex:range.location effectiveRange:NULL];
            [copy replaceCharactersInRange:range withString:replacement];
            [copy setAttributes:attributes range:NSMakeRange(range.location,replacement.length)];
        }];
        originalFieldAttributed(self, cmd, copy);
    } else originalFieldAttributed(self, cmd, value);
}
static void (*originalViewMoved)(NSView *, SEL);
static void viewMoved(NSView *self, SEL cmd) {
    originalViewMoved(self, cmd);
    if ([self isKindOfClass:NSTextField.class]) {
        NSTextField *field = (NSTextField *)self;
        if (!field.isEditable && !field.isSelectable && !translations[field.stringValue] && !skillDisplayTranslations[field.stringValue]) recordMissing(field.stringValue);
    }
    // Initial label text is often set before the view joins its settings pane.
    if ([self isKindOfClass:NSTextField.class] && isScopedLabel((NSTextField *)self)) {
        NSTextField *label = (NSTextField *)self;
        fieldAttributed(label, @selector(setAttributedStringValue:), label.attributedStringValue);
    }
}
static NSString *translate(NSString *text, const char *kind) {
    if (![text isKindOfClass:NSString.class]) return text;
    // Slash commands are translated only on UI surfaces, never in bundle lookups.
    NSString *result = translations[text] ?: (strcmp(kind, "bundle") != 0 ? skillDisplayTranslations[text] : nil);
    if (!result) { recordMissing(text); return text; }
    if (translationAudit) {
        flockfile(translationAudit);
        fprintf(translationAudit, "%s\t%s\n", kind, text.UTF8String);
        fflush(translationAudit);
        funlockfile(translationAudit);
    }
    return result;
}
static NSString *(*originalLocalized)(NSBundle *, SEL, NSString *, NSString *, NSString *);
static NSString *localized(NSBundle *self, SEL cmd, NSString *key, NSString *value, NSString *table) {
    NSString *result = originalLocalized(self, cmd, key, value, table);
    NSString *path = self.bundlePath;
    if ([path isEqualToString:appRoot] || [path hasPrefix:[appRoot stringByAppendingString:@"/"]])
        return translate(result, "bundle");
    return result;
}
static void (*originalMenuSetTitle)(NSMenuItem *, SEL, NSString *);
static void menuSetTitle(NSMenuItem *self, SEL cmd, NSString *title) {
    originalMenuSetTitle(self, cmd, translate(title, "menu"));
}
static id (*originalMenuInit)(NSMenuItem *, SEL, NSString *, SEL, NSString *);
static id menuInit(NSMenuItem *self, SEL cmd, NSString *title, SEL action, NSString *equivalent) {
    return originalMenuInit(self, cmd, translate(title, "menu-init"), action, equivalent);
}
static void (*originalButtonSetTitle)(NSButton *, SEL, NSString *);
static void (*originalTooltip)(NSView *, SEL, NSString *);
static void tooltip(NSView *self, SEL cmd, NSString *value) {
    originalTooltip(self, cmd, translate(value, "tooltip"));
}
static NSAttributedString *translatedAttributed(NSAttributedString *value) {
    if (!value) return nil;
    NSString *text = translate(value.string, "attributed-title");
    if ([text isEqualToString:value.string]) return value;
    NSMutableAttributedString *copy = [value mutableCopy];
    [copy replaceCharactersInRange:NSMakeRange(0, copy.length) withString:text];
    return copy;
}
static void (*originalMenuAttributed)(NSMenuItem *, SEL, NSAttributedString *);
static void menuAttributed(NSMenuItem *self, SEL cmd, NSAttributedString *value) {
    originalMenuAttributed(self, cmd, translatedAttributed(value));
}
static void (*originalButtonAttributed)(NSButton *, SEL, NSAttributedString *);
static void buttonAttributed(NSButton *self, SEL cmd, NSAttributedString *value) {
    originalButtonAttributed(self, cmd, translatedAttributed(value));
}
static void buttonSetTitle(NSButton *self, SEL cmd, NSString *title) {
    originalButtonSetTitle(self, cmd, translate(title, "button"));
}
__attribute__((constructor)) static void installLocalization(void) {
    @autoreleasepool {
        NSBundle *bundle = NSBundle.mainBundle;
        appRoot = [bundle.bundlePath copy];
        NSString *path = [bundle.resourcePath stringByAppendingPathComponent:@"DiaZhTranslations.json"];
        NSData *data = [NSData dataWithContentsOfFile:path];
        if (!data) return;
        id parsed = [NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
        if (![parsed isKindOfClass:NSDictionary.class]) return;
        for (id key in parsed) {
            if (![key isKindOfClass:NSString.class] || ![parsed[key] isKindOfClass:NSString.class]) return;
        }
        translations = [parsed copy];
        NSData *skillData = [NSData dataWithContentsOfFile:[bundle.resourcePath stringByAppendingPathComponent:@"DiaZhSkillDisplay.json"]];
        id skillParsed = skillData ? [NSJSONSerialization JSONObjectWithData:skillData options:0 error:NULL] : nil;
        if ([skillParsed isKindOfClass:NSDictionary.class]) skillDisplayTranslations = [skillParsed copy];
        const char *missingPath = getenv("DIA_ZH_MISSING_LOG");
        if (missingPath && *missingPath) {
            NSData *knownData = [NSData dataWithContentsOfFile:[bundle.resourcePath stringByAppendingPathComponent:@"DiaZhKnownUI.json"]];
            id candidates = knownData ? [NSJSONSerialization JSONObjectWithData:knownData options:0 error:NULL] : nil;
            if ([candidates isKindOfClass:NSArray.class]) {
                knownUI = [NSSet setWithArray:candidates];
                reportedMissing = [NSMutableSet set];
                missingAudit = fopen(missingPath, "a");
            }
        }
        const char *auditPath = getenv("DIA_ZH_AUDIT_LOG");
        if (auditPath && *auditPath) translationAudit = fopen(auditPath, "a");
        if (translationAudit) { fputs("module-loaded\n", translationAudit); fflush(translationAudit); }
        Method method = class_getInstanceMethod(NSBundle.class, @selector(localizedStringForKey:value:table:));
        originalLocalized = (void *)method_getImplementation(method);
        method_setImplementation(method, (IMP)localized);
        method = class_getInstanceMethod(NSMenuItem.class, @selector(setTitle:));
        originalMenuSetTitle = (void *)method_getImplementation(method);
        method_setImplementation(method, (IMP)menuSetTitle);
        method = class_getInstanceMethod(NSMenuItem.class, @selector(initWithTitle:action:keyEquivalent:));
        originalMenuInit = (void *)method_getImplementation(method);
        method_setImplementation(method, (IMP)menuInit);
        method = class_getInstanceMethod(NSButton.class, @selector(setTitle:));
        originalButtonSetTitle = (void *)method_getImplementation(method);
        method_setImplementation(method, (IMP)buttonSetTitle);
        method = class_getInstanceMethod(NSMenuItem.class, @selector(setAttributedTitle:));
        originalMenuAttributed = (void *)method_getImplementation(method);
        method_setImplementation(method, (IMP)menuAttributed);
        method = class_getInstanceMethod(NSButton.class, @selector(setAttributedTitle:));
        originalButtonAttributed = (void *)method_getImplementation(method);
        method_setImplementation(method, (IMP)buttonAttributed);
        method = class_getInstanceMethod(NSView.class, @selector(setToolTip:));
        originalTooltip = (void *)method_getImplementation(method);
        method_setImplementation(method, (IMP)tooltip);
        method = class_getInstanceMethod(NSTextField.class, @selector(setStringValue:));
        originalFieldString = (void *)method_getImplementation(method);
        class_addMethod(NSTextField.class, @selector(setStringValue:), (IMP)fieldString, method_getTypeEncoding(method));
        method_setImplementation(class_getInstanceMethod(NSTextField.class, @selector(setStringValue:)), (IMP)fieldString);
        method = class_getInstanceMethod(NSTextField.class, @selector(setAttributedStringValue:));
        originalFieldAttributed = (void *)method_getImplementation(method);
        class_addMethod(NSTextField.class, @selector(setAttributedStringValue:), (IMP)fieldAttributed, method_getTypeEncoding(method));
        method_setImplementation(class_getInstanceMethod(NSTextField.class, @selector(setAttributedStringValue:)), (IMP)fieldAttributed);
        method = class_getInstanceMethod(NSTextField.class, @selector(setPlaceholderString:));
        originalPlaceholder = (void *)method_getImplementation(method);
        class_addMethod(NSTextField.class, @selector(setPlaceholderString:), (IMP)placeholder, method_getTypeEncoding(method));
        method_setImplementation(class_getInstanceMethod(NSTextField.class, @selector(setPlaceholderString:)), (IMP)placeholder);
        method = class_getInstanceMethod(NSTextField.class, @selector(setPlaceholderAttributedString:));
        originalAttributedPlaceholder = (void *)method_getImplementation(method);
        class_addMethod(NSTextField.class, @selector(setPlaceholderAttributedString:), (IMP)attributedPlaceholder, method_getTypeEncoding(method));
        method_setImplementation(class_getInstanceMethod(NSTextField.class, @selector(setPlaceholderAttributedString:)), (IMP)attributedPlaceholder);
        method = class_getInstanceMethod(NSView.class, @selector(viewDidMoveToWindow));
        originalViewMoved = (void *)method_getImplementation(method);
        method_setImplementation(method, (IMP)viewMoved);
    }
}
