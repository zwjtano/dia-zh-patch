// These Swift-call-convention functions are referenced as addresses only.
extern void literalReplacement(void) __asm__("_dia_zh_key_literal");
extern void keyReplacement(void) __asm__("_dia_zh_key_string");
extern void textReplacement(void) __asm__("_dia_zh_text_string");
extern void literalOriginal(void) __asm__("_$s7SwiftUI18LocalizedStringKeyV13stringLiteralACSS_tcfC");
extern void keyOriginal(void) __asm__("_$s7SwiftUI18LocalizedStringKeyVyACSScfC");
extern void textOriginal(void) __asm__("_$s7SwiftUI4TextVyACxcSyRzlufC");
__attribute__((used, section("__DATA,__interpose")))
static const struct { const void *replacement; const void *original; } entries[] = {
    { literalReplacement, literalOriginal },
    { keyReplacement, keyOriginal },
    { textReplacement, textOriginal }
};
