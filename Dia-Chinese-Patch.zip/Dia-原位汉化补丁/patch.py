#!/usr/bin/env python3
"""Version-pinned, reversible resource patch. Never changes executable or signs it."""
import argparse, fcntl, hashlib, json, os, plistlib, shutil, subprocess, sys, tempfile
from pathlib import Path
BASE=Path(__file__).resolve().parent
MANIFEST=json.loads((BASE/'translations.json').read_text())
DEFAULT=BASE/'work'/'Dia-staging.app.disabled'
def digest(data): return hashlib.sha256(data).hexdigest()
def resources(app): return app/MANIFEST['resource_root']
def version(app):
 with (app/'Contents/Info.plist').open('rb') as f: info=plistlib.load(f)
 if (info.get('CFBundleIdentifier'),info.get('CFBundleShortVersionString'),info.get('CFBundleVersion')) != ('company.thebrowser.dia',MANIFEST['version'],MANIFEST['build']):
  raise ValueError('版本不匹配：仅支持 Dia 1.49.1（87398），未做修改。')
def states(app):
 version(app); result=[]
 for item in MANIFEST['files']:
  p=resources(app)/item['path']; h=digest(p.read_bytes())
  state='original' if h==item['sha256'] else 'patched' if h==item['patched_sha256'] else 'unknown'
  result.append(state)
 return result
def backup_dir(app):
 key=hashlib.sha256(str(app.resolve()).encode()).hexdigest()[:16]
 return Path.home()/'Library/Application Support/DiaZhPatch/backups'/key

def write_atomic(p,data):
 fd,tmp=tempfile.mkstemp(prefix='.dia-zh-',dir=p.parent)
 try:
  with os.fdopen(fd,'wb') as f: f.write(data);f.flush();os.fsync(f.fileno())
  shutil.copystat(p,tmp);os.replace(tmp,p)
 finally:
  if os.path.exists(tmp):os.unlink(tmp)

def running():
 out=subprocess.check_output(['/bin/ps','-axo','comm='],text=True)
 return any(line.strip().endswith('/Contents/MacOS/Dia') for line in out.splitlines())

def apply(app, prepared=False):
 if app.resolve()==Path('/Applications/Dia.app').resolve():raise ValueError('此实验补丁禁止修改正式版，请仅使用独立副本。')
 st=states(app)
 if all(s=='patched' for s in st): print('已应用补丁，无需重复操作。');return
 if any(s!='original' for s in st):raise ValueError('文件已被修改或更新，停止应用；未做修改。')
 if not prepared and running():raise ValueError('请先正常退出所有 Dia 窗口及进程，再运行补丁。')
 backup=backup_dir(app);backup.mkdir(parents=True,exist_ok=True)
 # Validate everything and write all backups before the first app mutation.
 plan=[]
 for item in MANIFEST['files']:
  p=resources(app)/item['path'];raw=p.read_bytes();s=raw.decode('utf-8')
  if digest(raw)!=item['sha256']:raise ValueError('校验期间文件发生变化，停止操作。')
  for c in item['changes']:
   if s.count(c['old'])!=c['count']:raise ValueError('文案位置不匹配，停止操作。')
   s=s.replace(c['old'],c['new'])
  patched=s.encode('utf-8')
  if digest(patched)!=item['patched_sha256']:raise ValueError('补丁输出校验失败。')
  b=backup/item['path'];b.parent.mkdir(parents=True,exist_ok=True)
  if b.exists() and digest(b.read_bytes())!=item['sha256']:raise ValueError('已有备份校验失败。')
  if not b.exists():shutil.copy2(p,b)
  plan.append((p,raw,patched))
 (backup/'receipt.json').write_text(json.dumps({'app':str(app),'version':MANIFEST['version'],'build':MANIFEST['build']},ensure_ascii=False,indent=2))
 changed=[]
 try:
  for p,raw,data in plan:
   if p.read_bytes()!=raw:raise ValueError('应用文件在写入前发生变化。')
   write_atomic(p,data);changed.append((p,raw))
  if any(s!='patched' for s in states(app)):raise ValueError('应用后的校验失败。')
 except BaseException:
  for p,raw in reversed(changed):write_atomic(p,raw)
  raise
 print('已应用 %d 条翻译（%d 处），校验通过。' % (sum(len(f['changes']) for f in MANIFEST['files']), sum(c['count'] for f in MANIFEST['files'] for c in f['changes'])))
 print('位置：'+str(app));print('原始资源备份：'+str(backup))
 print('此为离线开发副本，不能启动。签名/登录/原生界面尚未通过验证。')

def restore(app):
 st=states(app)
 if any(s=='unknown' for s in st):raise ValueError('检测到未知文件或更新，停止还原，避免覆盖新版本。')
 if all(s=='original' for s in st):print('已经是原版资源。');return
 if running():raise ValueError('请先正常退出所有 Dia 窗口及进程，再还原。')
 plan=[]
 for item,state in zip(MANIFEST['files'],st):
  if state=='original':continue
  p=resources(app)/item['path'];data=(backup_dir(app)/item['path']).read_bytes()
  if digest(data)!=item['sha256']:raise ValueError('备份校验失败；未还原。')
  plan.append((p,data))
 for p,data in plan:write_atomic(p,data)
 if any(s!='original' for s in states(app)):raise ValueError('还原校验失败。')
 print('已还原全部原版资源，校验通过。')

def main():
 parser=argparse.ArgumentParser(description='Dia 聊天界面简体中文实验补丁')
 parser.add_argument('action',choices=['prepare','apply','verify','restore'])
 parser.add_argument('--app',type=Path,default=DEFAULT)
 parser.add_argument('--source',type=Path,default=Path('/Applications/Dia.app'))
 args=parser.parse_args();app=args.app.expanduser().absolute()
 if args.action!='verify' and not app.name.endswith('.app.disabled'):
  raise ValueError('当前仅支持离线开发副本（名称须以 .app.disabled 结尾）；启动兼容性未验证，不生成可安装版。')
 lockdir=Path.home()/'Library/Application Support/DiaZhPatch';lockdir.mkdir(parents=True,exist_ok=True)
 with (lockdir/'patch.lock').open('w') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  if args.action=='prepare':
   source=args.source.expanduser().absolute()
   if app.exists():raise ValueError('目标已存在，未覆盖。可运行 verify 检查现有副本。')
   if any(s!='original' for s in states(source)):raise ValueError('源应用不是支持的原版。')
   app.parent.mkdir(parents=True,exist_ok=True)
   temporary=Path(tempfile.mkdtemp(prefix='.dia-zh-',dir=app.parent))
   try:
    clone=temporary/app.name
    subprocess.run(['/usr/bin/ditto',str(source),str(clone)],check=True)
    if any(s!='original' for s in states(clone)):raise ValueError('副本校验失败。')
    os.rename(clone,app)
   finally:shutil.rmtree(temporary)
   apply(app,prepared=True)
  elif args.action=='apply':apply(app)
  elif args.action=='restore':restore(app)
  else:
   st=states(app)
   for item,state in zip(MANIFEST['files'],st):print(state+'  '+item['path'])
   if 'unknown' in st or len(set(st))!=1:raise ValueError('文件状态不一致或未知。')
if __name__=='__main__':
 try:main()
 except (Exception,KeyboardInterrupt) as e:print('停止：'+str(e),file=sys.stderr);sys.exit(1)
