import Foundation
import SwiftUI

// Only reviewed settings labels. Does not hook text-field bindings or web content.
private let settingsTranslations: [String: String] = {
    guard let url = Bundle.main.url(forResource: "DiaZhSettings", withExtension: "json"),
          let data = try? Data(contentsOf: url),
          let result = try? JSONDecoder().decode([String:String].self, from: data) else { return [:] }
    return result
}()
private let slashDisplayLabels: [String: String] = {
    guard let url=Bundle.main.url(forResource:"DiaZhSkillDisplay",withExtension:"json"),
          let data=try? Data(contentsOf:url),
          let values=try? JSONDecoder().decode([String:String].self,from:data) else { return [:] }
    return values.filter { $0.key.hasPrefix("/") }
}()
private final class MissingUIRecorder {
    private let lock = NSLock()
    private var seen = Set<String>()
    private var candidates = Set<String>()
    private var file: FileHandle?
    init() {
        guard let path = ProcessInfo.processInfo.environment["DIA_ZH_MISSING_SWIFTUI_LOG"],
              let url = Bundle.main.url(forResource: "DiaZhKnownUI", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let values = try? JSONDecoder().decode([String].self, from: data) else { return }
        candidates = Set(values)
        if !FileManager.default.fileExists(atPath:path) {
            FileManager.default.createFile(atPath:path,contents:nil)
        }
        file = FileHandle(forWritingAtPath:path)
        file?.seekToEndOfFile()
    }
    func record(_ text: String) {
        guard candidates.contains(text), let file else { return }
        lock.lock(); defer { lock.unlock() }
        guard seen.insert(text).inserted else { return }
        if let bytes=(text+"\n").data(using:.utf8) { file.write(bytes) }
    }
}
private let missingRecorder = MissingUIRecorder()
private func translated(_ source: String) -> String {
    if let value=settingsTranslations[source] { return value }
    missingRecorder.record(source)
    return source
}
@_silgen_name("dia_zh_key_literal")
public func localizedLiteral(_ source: String) -> LocalizedStringKey {
    LocalizedStringKey(stringLiteral: translated(source))
}
@_silgen_name("dia_zh_key_string")
public func localizedKey(_ source: String) -> LocalizedStringKey {
    LocalizedStringKey(translated(source))
}
@_silgen_name("dia_zh_text_string")
public func localizedText<S: StringProtocol>(_ source: S) -> Text {
    // Use the separate verbatim initializer to avoid replacing this entry again.
    let text=String(source)
    return Text(verbatim: slashDisplayLabels[text] ?? translated(text))
}
