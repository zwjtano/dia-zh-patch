"""Add a localization dylib load command using existing zero header padding only."""
import struct
from pathlib import Path

def add_dylib(path, install_name):
    path=Path(path);data=bytearray(path.read_bytes())
    if len(data)<32:raise ValueError('Truncated Mach-O header')
    magic,cpu,_,kind,ncmds,sizeofcmds,_,_=struct.unpack_from('<8I',data)
    if magic!=0xfeedfacf or cpu!=0x0100000c or kind!=2:
        raise ValueError('Expected a thin arm64 executable')
    end=32+sizeofcmds
    if end>len(data):raise ValueError('Truncated load commands')
    cursor=32;first_section=len(data)
    for _ in range(ncmds):
        if cursor+8>end:raise ValueError('Invalid load-command count')
        cmd,size=struct.unpack_from('<II',data,cursor)
        if size<8 or size%8 or cursor+size>end:raise ValueError('Invalid load command')
        if cmd in (0xc,0x80000018,0x8000001f):
            nameoff=struct.unpack_from('<I',data,cursor+8)[0]
            if nameoff>=size:raise ValueError('Invalid library name')
            name=bytes(data[cursor+nameoff:cursor+size]).split(b'\0',1)[0]
            if name==install_name.encode():raise ValueError('Localization module already linked')
        if cmd==0x19:
            if size<72:raise ValueError('Invalid segment')
            count=struct.unpack_from('<I',data,cursor+64)[0]
            if 72+count*80>size:raise ValueError('Truncated section table')
            for i in range(count):
                offset=struct.unpack_from('<I',data,cursor+72+i*80+48)[0]
                if offset:first_section=min(first_section,offset)
        cursor+=size
    if cursor!=end:raise ValueError('Load-command size mismatch')
    encoded=install_name.encode()+b'\0';size=(24+len(encoded)+7)&~7
    if end+size>first_section or any(data[end:end+size]):
        raise ValueError('No safe zero-filled header space; refusing binary mutation')
    command=struct.pack('<6I',0xc,size,24,0,0,0)+encoded
    command+=bytes(size-len(command))
    data[end:end+size]=command
    struct.pack_into('<II',data,16,ncmds+1,sizeofcmds+size)
    path.write_bytes(data)
    return {'command_offset':end,'command_size':size,'original_commands':ncmds}
