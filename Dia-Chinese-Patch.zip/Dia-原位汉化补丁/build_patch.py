#!/usr/bin/env python3
"""Prepare a patched app internally, preserving the original app identity."""
import argparse,hashlib,json,os,plistlib,shutil,subprocess,tempfile
from pathlib import Path
import patch
from macho import add_dylib
BASE=Path(__file__).resolve().parent
SOURCE=Path('/Applications/Dia.app')

def run(*args):
 r=subprocess.run(args,text=True,capture_output=True)
 if r.returncode:raise RuntimeError(r.stderr or r.stdout)
 return r.stdout

def build(output, source=SOURCE):
 SOURCE=Path(source)
 if output.exists():raise ValueError('目标已存在；不覆盖现有应用。')
 patch.version(SOURCE)
 if set(patch.states(SOURCE))!={'original'}:raise ValueError('源文件校验失败。')
 run('/usr/bin/codesign','--verify','--deep','--strict',str(SOURCE))
 output.parent.mkdir(parents=True,exist_ok=True)
 with tempfile.TemporaryDirectory(prefix='.dia-zh-build-',dir=output.parent) as tmp:
  app=Path(tmp)/'DiaPreview.app'
  run('/usr/bin/ditto','--noextattr','--noqtn',str(SOURCE),str(app))
  # Mutate only validated resources. The official installation remains read-only.
  for f in patch.MANIFEST['files']:
   p=patch.resources(app)/f['path'];raw=p.read_bytes()
   if patch.digest(raw)!=f['sha256']:raise ValueError('副本校验失败。')
   s=raw.decode()
   for c in f['changes']:
    if s.count(c['old'])!=c['count']:raise ValueError('文案位置校验失败。')
    s=s.replace(c['old'],c['new'])
   if patch.digest(s.encode())!=f['patched_sha256']:raise ValueError('翻译结果校验失败。')
   p.write_text(s)
  # Compile our reviewed module locally; never download an injection binary.
  module=app/'Contents/Frameworks/DiaLocalization.dylib'
  run('/usr/bin/clang','-dynamiclib','-fobjc-arc','-framework','AppKit','-framework','Foundation','-Wall','-Wextra','-Werror',str(BASE/'DiaLocalization.m'),'-o',str(module))
  run('/usr/bin/codesign','--force','--sign','-',str(module))
  swift_object=Path(tmp)/'SwiftUIInterpose.o'
  swift_module=app/'Contents/Frameworks/DiaZhSwiftUI.dylib'
  run('/usr/bin/clang','-c',str(BASE/'SwiftUIInterpose.c'),'-o',str(swift_object))
  run('/usr/bin/xcrun','swiftc','-emit-library','-O',str(BASE/'SwiftUILocalization.swift'),str(swift_object),'-Xlinker','-install_name','-Xlinker','@executable_path/../Frameworks/DiaZhSwiftUI.dylib','-o',str(swift_module))
  run('/usr/bin/codesign','--force','--sign','-',str(swift_module))
  for name in ['DiaZhSettings.json','DiaZhSkillDisplay.json','DiaZhKnownUI.json']:
   shutil.copy2(BASE/name,app/'Contents/Resources'/name)
  shutil.copy2(BASE/'DiaZhTranslations.json',app/'Contents/Resources/DiaZhTranslations.json')
  binary_change=add_dylib(app/'Contents/MacOS/Dia','@executable_path/../Frameworks/DiaLocalization.dylib')
  add_dylib(app/'Contents/MacOS/Dia','@executable_path/../Frameworks/DiaZhSwiftUI.dylib')
  native=(BASE/'Localizable.strings').read_bytes()
  bundles=[app]+[p for p in (app/'Contents/Resources').glob('*.bundle') if p.name.startswith(('BoostBrowser_','ARCUI_','ARC_About','ARC_Window','ARC_Picture'))]
  for bundle in bundles:
   for lang in ['en','zh-Hans']:
    target=bundle/'Contents/Resources'/f'{lang}.lproj/Localizable.strings'
    if target.exists():raise ValueError('目标语言表已存在，不覆盖。')
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(native)
  # Keep Info.plist byte-for-byte: identity, profile location, Dock and updater.
  # Official provisioning and team-only entitlements cannot be claimed by a local build.
  provision=app/'Contents/embedded.provisionprofile'
  if provision.exists():provision.unlink()
  ent=Path(tmp)/'entitlements.plist'
  ent.write_bytes(plistlib.dumps({'com.apple.security.device.audio-input':True,'com.apple.security.device.camera':True,'com.apple.security.personal-information.location':True,'com.apple.security.cs.disable-library-validation':True}))
  # Resource bundles have their own seals; seal inside-out before the containing app.
  for bundle in bundles[1:]:run('/usr/bin/codesign','--force','--sign','-',str(bundle))
  run('/usr/bin/codesign','--force','--sign','-','--options','runtime','--entitlements',str(ent),str(app))
  run('/usr/bin/codesign','--verify','--deep','--strict',str(app))
  report={'status':'experimental_in_place_patch', 'version':'1.49.1', 'build':'87398', 'native_keys':len(json.loads((BASE/'DiaZhTranslations.json').read_text())), 'web_occurrences':277, 'native_bundles':len(bundles), 'identity_preserved':True, 'login_keychain_passkeys':'unverified', 'signature':'ad-hoc; restricted entitlements removed; library validation exception'}
  # Publish only after all static checks pass.
  os.rename(app,output)

 run('/usr/bin/codesign','--verify','--deep','--strict',str(SOURCE))
 print(json.dumps({'output':str(output),**report},ensure_ascii=False,indent=2))
