#!/bin/zsh
cd -- "${0:A:h}" || exit 1
/usr/bin/python3 installer.py check
result=$?
printf "\n按回车关闭窗口。"
read -r reply
exit "$result"
