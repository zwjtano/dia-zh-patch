#!/usr/bin/env python3
"""Version-pinned in-place patch with complete original app recovery."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import tempfile
import sys
import patch
from build_patch import build, run


def fingerprint(root):
    h = hashlib.sha256()
    for p in sorted(root.rglob('*')):
        s = p.lstat()
        h.update(str(p.relative_to(root)).encode() + b'\0')
        h.update(str(stat.S_IMODE(s.st_mode)).encode() + b'\0')
        if p.is_symlink():
            h.update(b'L' + os.readlink(p).encode())
        elif p.is_file():
            h.update(b'F')
            with p.open('rb') as f:
                for chunk in iter(lambda: f.read(1024 * 1024), b''):
                    h.update(chunk)
        else:
            h.update(b'D')
    return h.hexdigest()


def verify_signature(app):
    run('/usr/bin/codesign', '--verify', '--deep', '--strict', str(app))


def paths(app):
    store = app.parent / ('.' + app.stem + '-zh-patch-backup')
    return store, store / app.name, store / 'receipt.json'


def ensure_closed():
    if patch.running():
        raise ValueError('请先在 Dia 菜单中正常退出浏览器，再运行补丁。不会强制关闭你的窗口。')


def commit(app, candidate, original_hash, patched_hash):
    store, backup, receipt = paths(app)
    if store.exists():
        raise ValueError('已有备份或未完成的操作，请先运行还原。')
    if fingerprint(app) != original_hash:
        raise ValueError('原版在准备期间发生变化，未安装。')
    store.mkdir(mode=0o700)
    # Journal exists before any application move, allowing interrupted recovery.
    with receipt.open('w') as f:
        json.dump({'app': str(app), 'original': original_hash,
                   'patched': patched_hash, 'version': '1.49.1', 'build': '87398'}, f)
        f.flush()
        os.fsync(f.fileno())
    try:
        os.rename(app, backup)
        os.rename(candidate, app)
        verify_signature(app)
        if fingerprint(app) != patched_hash:
            raise ValueError('安装后校验失败。')
    except BaseException:
        if backup.exists():
            if app.exists():
                os.rename(app, candidate)
            os.rename(backup, app)
        if app.exists() and fingerprint(app) == original_hash:
            shutil.rmtree(store)
        raise


def install(app):
    ensure_closed()
    patch.version(app)
    if paths(app)[0].exists():
        raise ValueError('已有补丁备份；请先还原，不能重复覆盖。')
    if set(patch.states(app)) != {'original'}:
        raise ValueError('资源并非匹配的原版，未修改。')
    verify_signature(app)
    # codesign writes identity to stderr, so verify team using designated requirement.
    run('/usr/bin/codesign', '--verify', '-R',
        '=anchor apple generic and certificate leaf[subject.OU] = "S6N382Y83G"', str(app))
    before = fingerprint(app)
    print('正在准备补丁并校验；正式版尚未改动。', flush=True)
    with tempfile.TemporaryDirectory(prefix='.dia-zh-prepare-', dir=app.parent) as tmp:
        candidate = Path(tmp) / app.name
        build(candidate, app)
        if (candidate/'Contents/Info.plist').read_bytes() != (app/'Contents/Info.plist').read_bytes():
            raise ValueError('应用身份校验失败。')
        after = fingerprint(candidate)
        ensure_closed()
        commit(app, candidate, before, after)
    print('补丁已应用到原来的 Dia。完整原版备份：' + str(paths(app)[1]))


def restore(app):
    ensure_closed()
    store, backup, receipt = paths(app)
    data = json.loads(receipt.read_text())
    if data['app'] != str(app):
        raise ValueError('备份对应另一安装位置。')
    if not backup.exists():
        if app.exists() and fingerprint(app) == data['original']:
            shutil.rmtree(store)
            print('原版完整；已清理未完成的安装记录。')
            return
        raise ValueError('缺少原版备份，停止还原。')
    if fingerprint(backup) != data['original']:
        raise ValueError('原版备份损坏，未修改。')
    verify_signature(backup)
    if app.exists() and fingerprint(app) != data['patched']:
        raise ValueError('Dia 已更新或被其他工具修改；为避免覆盖新版本，自动还原已停止。原版备份仍保留。')
    displaced = store / 'patched-app.saved'
    if displaced.exists():
        raise ValueError('存在未完成还原，请保留此目录以便恢复。')
    if app.exists():
        os.rename(app, displaced)
    try:
        os.rename(backup, app)
        verify_signature(app)
        if fingerprint(app) != data['original']:
            raise ValueError('还原校验失败。')
    except BaseException:
        if app.exists():
            os.rename(app, backup)
        if displaced.exists():
            os.rename(displaced, app)
        raise
    shutil.rmtree(store)
    print('已还原完整原版及官方签名。浏览器资料未作修改。')


def main():
    parser = argparse.ArgumentParser(description='Dia 原位汉化补丁（实验版）')
    parser.add_argument('action', choices=['check', 'install', 'restore'])
    parser.add_argument('--app', type=Path, default=Path('/Applications/Dia.app'))
    args = parser.parse_args()
    app = args.app.expanduser().absolute()
    if app.is_symlink() or not app.name.endswith('.app'):
        raise ValueError('请选择实际的 Dia.app 安装目录。')
    lockdir = Path.home()/'Library/Application Support/DiaZhPatch'
    lockdir.mkdir(parents=True, exist_ok=True)
    with (lockdir/'in-place.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if args.action == 'check':
            patch.version(app)
            verify_signature(app)
            print('版本：Dia 1.49.1（87398）；资源状态：' + ', '.join(sorted(set(patch.states(app)))))
            print('实验性深度补丁；登录、钥匙串、通行密钥兼容性未验证。')
        elif args.action == 'install':
            print('此实验补丁会修改现有 Dia 并改为本地签名，移除官方专属权限，允许加载汉化模块。')
            print('登录、钥匙串、通行密钥可能受影响；完整原版可还原，但这不等于资料备份。')
            install(app)
        else:
            restore(app)


if __name__ == '__main__':
    try:
        main()
    except (Exception, KeyboardInterrupt) as error:
        print('停止：' + str(error), file=sys.stderr)
        sys.exit(1)
